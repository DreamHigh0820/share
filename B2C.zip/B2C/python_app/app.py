from flask import Flask, render_template, request, redirect, url_for
import pyodbc
from elasticsearch import Elasticsearch
import pandas as pd
import re
import os

app = Flask(__name__)

# Route to upload the pipeline configuration file
@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # Save uploaded file
        file = request.files['file']
        if file:
            filepath = os.path.join('uploads', 'pipeline.conf')
            os.makedirs('uploads', exist_ok=True)  # Create the uploads folder if it does not exist
            file.save(filepath)
            return redirect(url_for('process_file'))
    return render_template('upload.html')

# Route to process the pipeline configuration file
@app.route('/process', methods=['GET', 'POST'])
def process_file():
    if request.method == 'POST':
        sql_server = request.form['sql_server']
        sql_user = request.form['sql_user']
        sql_password = request.form['sql_password']
        es_host = request.form['es_host']

        # Read pipeline configuration file
        with open('uploads/pipeline.conf', 'r') as f:
            pipeline_conf = f.read()

        # Extract SQL columns from the SELECT statement
        sql_columns = re.findall(r'SELECT\s+(.*?)\s+FROM', pipeline_conf, re.DOTALL | re.IGNORECASE)
        if sql_columns:
            columns = [col.strip().strip(',') for col in sql_columns[0].split('\n') if col.strip()]
        else:
            columns = []

        # Connect to SQL Server using pyodbc
        conn = pyodbc.connect(
            f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={sql_server};DATABASE=master;UID={sql_user};PWD={sql_password}"
        )
        sql_df = pd.read_sql('SELECT * FROM v_es_cdm_hwam', conn)
        conn.close()

        # Connect to Elasticsearch
        es = Elasticsearch([es_host])

        # Fetch data from Elasticsearch
        es_res = es.search(index='cdm_hwam', body={"query": {"match_all": {}}}, size=1000)
        es_hits = es_res['hits']['hits']
        es_df = pd.json_normalize([hit['_source'] for hit in es_hits])

        # Compare data
        comparison = sql_df.merge(es_df, indicator=True, how='outer')

        # Save CSV files
        sql_df.to_csv('sql_data.csv', index=False)
        es_df.to_csv('es_data.csv', index=False)

        return render_template('result.html', columns=columns, sql_data=sql_df.head().to_html(), es_data=es_df.head().to_html(), comparison=comparison.to_html())

    return render_template('credentials.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)